﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formBTNShortCut
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnShortCutSubmit = New System.Windows.Forms.Button()
        Me.tbxNewShortCutSug = New System.Windows.Forms.TextBox()
        Me.tbxNewShortCutFat = New System.Windows.Forms.TextBox()
        Me.tbxNewShortCutCarb = New System.Windows.Forms.TextBox()
        Me.tbxNewShortCutProt = New System.Windows.Forms.TextBox()
        Me.tbxNewShortCutCal = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tbxNewShortCutBrand = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tbxNewShortCutName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tbxNewShortCutButtonName = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(87, 347)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(443, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "5 Buttons to change their name and their values of what food it supposed to deliv" &
    "er in 1 click"
        '
        'btnShortCutSubmit
        '
        Me.btnShortCutSubmit.Location = New System.Drawing.Point(12, 415)
        Me.btnShortCutSubmit.Name = "btnShortCutSubmit"
        Me.btnShortCutSubmit.Size = New System.Drawing.Size(98, 23)
        Me.btnShortCutSubmit.TabIndex = 1
        Me.btnShortCutSubmit.Text = "Submit and Close"
        Me.btnShortCutSubmit.UseVisualStyleBackColor = True
        '
        'tbxNewShortCutSug
        '
        Me.tbxNewShortCutSug.Location = New System.Drawing.Point(644, 36)
        Me.tbxNewShortCutSug.Name = "tbxNewShortCutSug"
        Me.tbxNewShortCutSug.Size = New System.Drawing.Size(75, 20)
        Me.tbxNewShortCutSug.TabIndex = 37
        Me.tbxNewShortCutSug.Text = "0"
        '
        'tbxNewShortCutFat
        '
        Me.tbxNewShortCutFat.Location = New System.Drawing.Point(725, 36)
        Me.tbxNewShortCutFat.Name = "tbxNewShortCutFat"
        Me.tbxNewShortCutFat.Size = New System.Drawing.Size(75, 20)
        Me.tbxNewShortCutFat.TabIndex = 36
        Me.tbxNewShortCutFat.Text = "0"
        '
        'tbxNewShortCutCarb
        '
        Me.tbxNewShortCutCarb.Location = New System.Drawing.Point(563, 36)
        Me.tbxNewShortCutCarb.Name = "tbxNewShortCutCarb"
        Me.tbxNewShortCutCarb.Size = New System.Drawing.Size(75, 20)
        Me.tbxNewShortCutCarb.TabIndex = 35
        Me.tbxNewShortCutCarb.Text = "0"
        '
        'tbxNewShortCutProt
        '
        Me.tbxNewShortCutProt.Location = New System.Drawing.Point(482, 36)
        Me.tbxNewShortCutProt.Name = "tbxNewShortCutProt"
        Me.tbxNewShortCutProt.Size = New System.Drawing.Size(75, 20)
        Me.tbxNewShortCutProt.TabIndex = 34
        Me.tbxNewShortCutProt.Text = "0"
        '
        'tbxNewShortCutCal
        '
        Me.tbxNewShortCutCal.Location = New System.Drawing.Point(401, 36)
        Me.tbxNewShortCutCal.Name = "tbxNewShortCutCal"
        Me.tbxNewShortCutCal.Size = New System.Drawing.Size(75, 20)
        Me.tbxNewShortCutCal.TabIndex = 33
        Me.tbxNewShortCutCal.Text = "0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(722, 20)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(22, 13)
        Me.Label8.TabIndex = 32
        Me.Label8.Text = "Fat"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(641, 20)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(35, 13)
        Me.Label7.TabIndex = 31
        Me.Label7.Text = "Sugar"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(560, 20)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(34, 13)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Carbs"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(482, 20)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 13)
        Me.Label5.TabIndex = 29
        Me.Label5.Text = "Proteins"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(398, 20)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 28
        Me.Label4.Text = "Calories"
        '
        'tbxNewShortCutBrand
        '
        Me.tbxNewShortCutBrand.Location = New System.Drawing.Point(277, 36)
        Me.tbxNewShortCutBrand.Name = "tbxNewShortCutBrand"
        Me.tbxNewShortCutBrand.Size = New System.Drawing.Size(115, 20)
        Me.tbxNewShortCutBrand.TabIndex = 27
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(274, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 26
        Me.Label3.Text = "Brand"
        '
        'tbxNewShortCutName
        '
        Me.tbxNewShortCutName.Location = New System.Drawing.Point(110, 36)
        Me.tbxNewShortCutName.Name = "tbxNewShortCutName"
        Me.tbxNewShortCutName.Size = New System.Drawing.Size(161, 20)
        Me.tbxNewShortCutName.TabIndex = 25
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(107, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Name"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(9, 20)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 13)
        Me.Label9.TabIndex = 38
        Me.Label9.Text = "Button Name"
        '
        'tbxNewShortCutButtonName
        '
        Me.tbxNewShortCutButtonName.Location = New System.Drawing.Point(4, 36)
        Me.tbxNewShortCutButtonName.Name = "tbxNewShortCutButtonName"
        Me.tbxNewShortCutButtonName.Size = New System.Drawing.Size(100, 20)
        Me.tbxNewShortCutButtonName.TabIndex = 39
        '
        'formBTNShortCut
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.tbxNewShortCutButtonName)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.tbxNewShortCutSug)
        Me.Controls.Add(Me.tbxNewShortCutFat)
        Me.Controls.Add(Me.tbxNewShortCutCarb)
        Me.Controls.Add(Me.tbxNewShortCutProt)
        Me.Controls.Add(Me.tbxNewShortCutCal)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.tbxNewShortCutBrand)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.tbxNewShortCutName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnShortCutSubmit)
        Me.Controls.Add(Me.Label1)
        Me.Name = "formBTNShortCut"
        Me.Text = "ShortCut Settings"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents btnShortCutSubmit As Button
    Friend WithEvents tbxNewShortCutSug As TextBox
    Friend WithEvents tbxNewShortCutFat As TextBox
    Friend WithEvents tbxNewShortCutCarb As TextBox
    Friend WithEvents tbxNewShortCutProt As TextBox
    Friend WithEvents tbxNewShortCutCal As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents tbxNewShortCutBrand As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents tbxNewShortCutName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents tbxNewShortCutButtonName As TextBox
End Class
